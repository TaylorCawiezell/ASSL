(function() {
  var app = angular.module('tasksms', []);
    


app.controller('loginController', function(){
   this.form = true;
   this.signup = true;
   
        
 });
    
    app.controller('messageController', function(){
   this.timed = true;

   
        
 });
              
})();
